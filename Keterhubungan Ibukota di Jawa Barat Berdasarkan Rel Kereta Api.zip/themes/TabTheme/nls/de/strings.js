define({
  "_themeLabel": "Tab-Design",
  "_layout_default": "Standard-Layout",
  "_layout_layout1": "Layout 1"
});