define({
  "_themeLabel": "Tema da Guia",
  "_layout_default": "Layout padrão",
  "_layout_layout1": "Layout 1"
});