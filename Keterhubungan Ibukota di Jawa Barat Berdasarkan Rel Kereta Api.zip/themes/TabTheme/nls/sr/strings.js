define({
  "_themeLabel": "Tema kartice",
  "_layout_default": "Podrazumevani raspored",
  "_layout_layout1": "Raspored 1"
});