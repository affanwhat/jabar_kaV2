define({
  "_themeLabel": "Fül téma",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_layout1": "1. elrendezés"
});