define({
  "_themeLabel": "Tabbladthema",
  "_layout_default": "Standaardlay-out",
  "_layout_layout1": "Lay-out 1"
});