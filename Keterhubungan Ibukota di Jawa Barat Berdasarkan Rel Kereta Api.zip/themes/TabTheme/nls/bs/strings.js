define({
  "_themeLabel": "Tema kartice",
  "_layout_default": "Zadani izgled",
  "_layout_layout1": "Izgled 1"
});