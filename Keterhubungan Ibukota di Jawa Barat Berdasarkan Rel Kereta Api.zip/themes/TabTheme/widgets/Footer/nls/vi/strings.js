define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "Cuối trang"
});