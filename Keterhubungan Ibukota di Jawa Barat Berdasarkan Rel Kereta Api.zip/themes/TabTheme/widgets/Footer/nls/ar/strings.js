define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "أسفل الصفحة"
});