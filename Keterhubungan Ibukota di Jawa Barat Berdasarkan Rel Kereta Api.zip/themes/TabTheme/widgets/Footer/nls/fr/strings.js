define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "Pied de page"
});