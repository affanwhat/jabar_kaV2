define({
  "appCopyright": "All rights reserved",
  "_widgetLabel": "Lábjegyzet"
});